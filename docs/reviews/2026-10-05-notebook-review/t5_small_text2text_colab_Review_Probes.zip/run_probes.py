"""T5S review probes (torch-free). Usage: python run_probes.py <repo checkout> <out dir>"""
import json, os, sys, types, re, hashlib, subprocess
from pathlib import Path

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/t5_small_text2text_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
import t5_small_text2text_pipeline.pipeline as P
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
alltext = '\n'.join(src(i) for i in range(len(cells)))
R['P1_static'] = {'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3), 'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'pins': re.findall(r"'([a-z0-9_.-]+==[^']+)'", src(3)),
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Predict', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Next experiments', 'Conclusion', '<details>']},
    'metric_helpers_in_module': [n for n in dir(P) if 'rouge' in n.lower() or 'bleu' in n.lower() or 'metric' in n.lower()],
    'default_sample_has_references': False}
gf = nb['metadata']['dimer']['generated_from']
at = subprocess.run(['git', '-C', str(repo), 'show', f"{gf['revision']}:{gf['module']}"], capture_output=True).stdout
R['P1_static']['module_sha256_at_generated_from_matches'] = hashlib.sha256(at).hexdigest() == gf['module_sha256']

# P2 evaluation_report: verdict with and without a reference
r0 = {'text': 'Das Haus ist wunderbar.', 'known_prefix': 'translate English to German: ', 'generated_tokens': 7, 'input_tokens': 11, 'stopped_by': 'eos', 'generation': {'max_new_tokens': 64, 'num_beams': 1, 'do_sample': False}, 'model_id': P.MODEL_ID, 'model_revision': P.MODEL_REVISION}
import inspect
sig = str(inspect.signature(P.evaluation_report))
def er(**kw):
    try:
        rep = P.evaluation_report(r0, **kw); return {'verdict': rep.get('verdict'), 'reason': str(rep.get('reason'))[:200], 'metrics': rep.get('metrics')}
    except Exception as e: return {'error': f'{type(e).__name__}: {e}'[:200]}
R['P2_evaluation_report'] = {'signature': sig, 'no_reference': er(sample_kind='synthetic'), 'with_exact_reference': er(sample_kind='synthetic', **({'references': ['Das Haus ist wunderbar.']} if 'reference' in sig else {}))}

# P3 BYOD branch of cell 9 with stand-ins, then validate_inputs as cell 11 does
c9 = src(9).replace('USE_BYOD = False', 'USE_BYOD = True').split("item_ids = [")[0]
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:200]}
def byod(uploaded, colab=True):
    for k in ('google', 'google.colab'): sys.modules.pop(k, None)
    if colab:
        cm = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = cm; cm.files = types.SimpleNamespace(upload=lambda: uploaded)
        sys.modules['google'] = g; sys.modules['google.colab'] = cm
    ns = {}; exec(compile(c9, 'cell9', 'exec'), ns)
    m = P.validate_inputs(ns['texts'], max_new_tokens=64, num_beams=1, names=[f'input{i:02d}' for i in range(len(ns['texts']))])
    return {'inputs': len(ns['texts']), 'known_prefix': [e['known_prefix'] for e in m['inputs']], 'verdict': m['verdict']}
cases = {
    'two prefixed lines': {'in.txt': b'translate English to German: Hello.\nsummarize: A long passage about things.\n'},
    'CRLF line endings': {'in.txt': b'translate English to French: Hello.\r\nsummarize: Text.\r\n'},
    'UTF-8 BOM': {'in.txt': b'\xef\xbb\xbftranslate English to German: Hello.\n'},
    'line without a prefix': {'in.txt': b'Please summarise this text for me.\n'},
    'Latin-1 bytes (not UTF-8)': {'in.txt': 'translate English to German: Caf\xe9.\n'.encode('latin-1')},
    'empty file': {'in.txt': b'\n\n'},
    'one line over MAX_TEXT_CHARS': {'in.txt': ('summarize: ' + 'x' * (P.MAX_TEXT_CHARS + 1) + '\n').encode()},
    'cancelled dialog': {},
}
P3 = [run(n, lambda u=u: byod(u)) for n, u in cases.items()]
P3.append(run('outside Colab', lambda: byod(None, colab=False)))
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
R['P3_byod'] = {'matrix': P3, 'has_path_field': bool(re.search(r'BYOD_(PATH|FILE)\s*=', src(9))), 'MAX_TEXT_CHARS': P.MAX_TEXT_CHARS, 'MAX_INPUT_TOKENS': P.MAX_INPUT_TOKENS}
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:7000])
